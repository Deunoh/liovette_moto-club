</main>
<footer>
    <p>&copy; <?php echo date('Y'); ?> - Liovette Club Beauvais - Création <a href="https://denovann.fr/" target="_blank">Denovann Belloir</a></p>
</footer>
<?php wp_footer(); ?>
</body>
</html>